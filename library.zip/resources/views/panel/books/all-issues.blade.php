<div class="module">
    <div class="module-body">
        <div class="row-fluid">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Log ID</th>
                        <th>Book Issue ID</th>
                        <th>Book Name</th>
                        <th>Student Name</th>
                        <th>Issued On</th>
                        <th>Return Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="issue-logs-table">
                    <tr class="text-center">
                        <td colspan="12">Loading...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
