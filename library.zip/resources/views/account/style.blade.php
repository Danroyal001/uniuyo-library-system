<style>
    .wrapper {
        background-image: url({{ asset('images/bg-1.jpg') }});
        background-color: #cccccc;
        height: 90vh;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        position: relative;
    }

    .wrapper1 {
        background-image: url({{ asset('images/bg-2.jpg') }});
        background-color: #cccccc;
        height: 90vh;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        position: relative;
    }

    .displaySearchBooks {
        height: 350px;
        overflow-x: auto;
    }
</style>
