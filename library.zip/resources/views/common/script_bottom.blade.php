<script type="text/javascript">    
    
</script>

@yield('custom_bottom_script')